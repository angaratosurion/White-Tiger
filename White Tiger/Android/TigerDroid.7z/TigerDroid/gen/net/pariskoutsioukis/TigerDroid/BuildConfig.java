/** Automatically generated file. DO NOT MODIFY */
package net.pariskoutsioukis.TigerDroid;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}