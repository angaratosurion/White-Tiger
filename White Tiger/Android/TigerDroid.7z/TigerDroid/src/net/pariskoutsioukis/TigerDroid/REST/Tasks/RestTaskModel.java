package net.pariskoutsioukis.TigerDroid.REST.Tasks;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

public class RestTaskModel {
	public DefaultHttpClient client;
	public HttpPost Request;
	

}
