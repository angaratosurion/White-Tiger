package net.pariskoutsioukis.TigerDroid.xml;
import android.database.Cursor;
import android.util.Log;
import android.util.Xml;
import android.widget.CursorAdapter;
import net.pariskoutsioukis.TigerDroid.Tools;
import net.pariskoutsioukis.TigerDroid.Sqllite.SqlLiteManager;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.helpers.XMLReaderAdapter;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import com.android.internal.util.XmlUtils;

import android.content.Context;
import android.widget.ArrayAdapter;

import javax.xml.parsers.DocumentBuilder;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
public class xml {
public final String Tabletag="pynakas";
public final String recordtag="eggrafi";

public SqlLiteManager  AttachXmltoSQLLite(SqlLiteManager sqlmngr,File xml, String ele)
{
    try
    { 
    	SqlLiteManager ap =null;
    	 XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
         factory.setNamespaceAware(true);
         XmlPullParser xpp = factory.newPullParser();
        
       
    

        if((sqlmngr!=null)&&(xml!=null) &&(ele !=null)) 
        {
        	 xpp.setInput(new FileReader(xml));
             int eventType = xpp.getEventType();
             while (eventType != XmlPullParser.END_DOCUMENT) 
             {
            	 ArrayList<String> text = new ArrayList<String>();
            	 if(eventType==XmlPullParser.START_TAG)
            	 {
            		 System.out.println("Tstarttag "+xpp.getName());
            	 }
            	 else if(eventType == XmlPullParser.TEXT) 
            	 {
                     System.out.println("Text "+xpp.getText());
                     text.add(xpp.getText());
                 }
            	 else if (eventType==XmlPullParser.END_TAG)
            	 {
            		 if(xpp.getName()==ele)
            		 {
            			 System.out.println("size "+text.size());
            			 sqlmngr.addNewRecord(text.toArray());
            			
            		 }
            	 }
            	 
            	 
            	 System.out.println("size "+text.size());
            	  
            	  eventType = xpp.next();
            	 
             }
           

        }
     return sqlmngr;
    }
    catch (Exception e)
    {
        Tools.Errorhandling(e);
        return null;
    }
}

	public XmlPullParser ReadXml(String txml)
	{
		try
		{ 
			XmlPullParser ap=null;
			StringReader rdr;
			XmlPullParserFactory factory= XmlPullParserFactory.newInstance();
			factory.setNamespaceAware(true);
			if(txml !=null)
			{
				//InputStream input = new InputStream();
				rdr=  new StringReader(txml);
				
				ap= factory.newPullParser();
				ap.setInput(rdr);

				
				
				//ap.
				
			}
		
		
		
			
		return ap;	
		}
		catch(Exception ex)
		{
			Tools.Errorhandling(ex);
			return null;
		}
		
		
	}
 public String  SaveXml(CursorAdapter vals)
 {
     try {
         String ap=null;
         if ( vals !=null )
         {

              for (int i=0;i<vals.getCount();i++)
              {


              }

         }



         return ap;
     }
     catch (Exception ex) {
         Tools.Errorhandling(ex);
         return null;
     }
 }


	
}

