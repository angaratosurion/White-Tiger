package net.pariskoutsioukis.TigerDroid.REST;

/*
public class AsyncRestClient extends AsyncHttpClient {

	public AsyncRestClient(AsyncServer server) {
		super(server);
		// TODO Auto-generated constructor stub
	//	this.
	}

	//@Overide
	
	

}*/
