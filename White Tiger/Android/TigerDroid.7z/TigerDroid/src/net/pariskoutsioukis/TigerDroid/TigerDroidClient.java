package net.pariskoutsioukis.TigerDroid;
//import android.app.Activity;

import java.io.File;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.InetAddress;
import java.net.URI;
import java.util.ArrayList;

import android.util.Log;
import net.pariskoutsioukis.TigerDroid.Sqllite.SqlLiteManager;

import net.pariskoutsioukis.TigerDroid.json.JSon;
import net.pariskoutsioukis.TigerDroid.wcf.White_Tigerservice;
import net.pariskoutsioukis.TigerDroid.xml.*;

import org.apache.http.client.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.*;
import org.apache.http.impl.client.*;
import org.apache.http.*;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.helpers.*;
import org.xmlpull.v1.XmlPullParser;

import android.database.*;
//import org.apache.hdttp.client.params;
public class TigerDroidClient extends White_Tigerservice {
  //
   // DefaultHttpClient client = new DefaultHttpClient();
    String uri;
    Tools tools = new Tools();
    //xml xmlmngr = new xml();
    DOMManager xmlmnger = new DOMManager();

    public String[] Cells;
    public static   final int dport=49152;
   // public Client client;
   // String res;
  //  Boolean resrec=false;

    public   TigerDroidClient()
    {
       // client = new Client();

     // this.start();




    }
    public String GetElemntName(String username,String dbname)
    {
        try {
            String ap = "";
            if ((username != null)&&(dbname!=null)) {


               ap=username+"_"+dbname;

            }

            return ap;
        }

        catch( Exception ex)
        {
            Tools.Errorhandling(ex);
            return null;

        }
    }
    public TigerDroidClient(String serverip)
    {
        super(serverip);
    }
    private boolean isCellTag(String localName)
    {
        try {
            boolean ap = false;
            if (localName != null) {

                for (int i = 0; i < Cells.length; i++)
                {
                    if (Cells[i] == localName)
                    {
                        return true;
                    }


                }


            }

            return ap;
        }

        catch( Exception ex)
        {
            Tools.Errorhandling(ex);
            return false;

        }

    }
    public SqlLiteManager LoadTableToSQLLite(String recordtag,String username,String pass,String dbname,String tablename
            ,SqlLiteManager sqlmngr,String [] cells)
    {
        try
        {
            SqlLiteManager ap=null;


            if((username!=null) &&(pass!=null) &&(dbname!=null)
                    &&(tablename!=null) &&(recordtag!=null) &&(sqlmngr!=null) &&(cells!=null))
            {
                String xml= this.LoadTable(recordtag, username, pass, dbname, tablename);




                sqlmngr.CreateorOpenDB(dbname,tablename,cells);

                    // ap= xmlmnger.AttachXmltoSQLLite(sqlmngr,xml,this.GetElemntName(username,tablename));


                }











        return ap;
        }
        catch(Exception ex)
        {
            Tools.Errorhandling(ex);
            return null;


        }
    }
    public SqlLiteManager DecryptTable(String root, String recordtag, String username, String dbname, String table, String pass,
                                      String alg, String hashalg,String passphrase,SqlLiteManager sqlmngr)
    {
        try
        {
            SqlLiteManager ap=null;

            String [] params = new String[9];
            if((root!=null)&&(recordtag!=null)&&(username!=null)&&
                    (dbname!=null)&&(table!=null)&&
                    (pass!=null)&&(alg!=null) &&
                    (hashalg!=null)&&(passphrase!=null) &&(sqlmngr!=null))

            {
                params[0]=root;
                params[1]=recordtag;
                params[2]=username;
                params[3]=dbname;
                params[4]=table;
                params[5]=pass;
                params[6]=alg;
                params[7]=hashalg;
                params[8]=passphrase;
                File xml=    new File(this.Decrypt(root,recordtag, username, dbname,table, pass,alg,hashalg,
                        passphrase));
             ap=  xmlmnger.AttachXmltoSQLLite(sqlmngr,xml,this.GetElemntName(username,table));




            }
          return ap;
        }
        catch(Exception ex)
        {
            Tools.Errorhandling(ex);
         return null;


        }
    }

 /*   public String GetURI() {
        try {

            return uri;

        } catch (Exception ex) {

            Tools.Errorhandling(ex);
            return null;


        }


    }

    public void SetURI(String serverip) {


        try {
            if (serverip!= null) {

                uri ="http://"+ serverip+"/White_Tiger/";

            }

        } catch (Exception ex) {
            //return null;
            Tools.Errorhandling(ex);

        }

    }       */


    /*


    public String GetServerVersion() {

        try {
            String ap = null;


            ap =


            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }
    }






    public String[] ListDatabses(String username, String pass) {
        try {
            String[] ap = null;

            if ((username != null) && (pass != null)) {
                String[] params = new String[2];
                params[0] = username;
                params[1] = pass;
                //ap=this.jsmngr.GetArray("ListDatabases",  ExecuteGetCommand("ListDatabases", params));
               // ap = this.xmlmngr.GetArray(this.jsmngr.GetValues("ListDatabasesResult"+res));


            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }


    }

    public String[] ListTables(String username, String pass, String dbname) {
        try {
            String[] ap = null;

            if ((username != null) && (pass != null) && (dbname != null)) {
                String[] params = new String[13];
                params[2] = username;
                params[3] = pass;
             //  ap= this.jsmngr.GetArray("ListTables",ExecuteGetCommand("ListTables",params));
              //  ap = null;

            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }


    }


    public XmlPullParser LoadTable(String recordtag, String username, String pass, String dbname, String tablename) {
        try {
            XmlPullParser ap = null;

            if ((username != null) && (pass != null) && (dbname != null)
                    && (tablename != null) && (recordtag != null)) {
                String[] params = new String[12];
                params[0] = recordtag;
                params[1] = username;
                params[2] = pass;
                params[3] = dbname;
                params[4] = tablename;
          //      ap = xmlmngr.ReadXml(this.jsmngr.GetValues("LoadTable",ExecuteGetCommand("LoadTable", params)));


            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }
    }







public Boolean IsTableEncrypted(String username, String pass, String dbname, String tablename)
{try
{
	Boolean ap=false;
	
	if((username!=null) &&(pass!=null))
	{
		String [] params= new  String [13];
		params[2]=username;
		params[3]=pass;
		params[4]=dbname;
		params[5]=tablename;
	//	ap= Boolean.parseBoolean(this.jsmngr.GetValues("IsTableEncrypted",ExecuteGetCommand("IsTableEncrypted",params )));
		
		
	}
	
	return ap;
}
catch(Exception ex)
{
	Tools.Errorhandling(ex);
	return false;
	
	
}
	
	
}
public String [] GetColumns(String username, String pass, String dbname, String tablename)
{
	try
	{ String [] ap=null;
		if((username!=null) &&(pass!=null) &&(dbname !=null)&&(tablename!=null))
		{
			String [] params= new  String [13];
			params[2]=username;
			params[3]=pass;
			params[4]=dbname;
			params[5]=tablename;
		//	ap= this.jsmngr.GetArray("GetColumns", this.ExecuteGetCommand("GetColumns", params));
         //   ap=res.split(",");
			
		}
		return ap;
		
	}
	catch(Exception ex)
	{
		Tools.Errorhandling(ex);
		return null;
		
		
	}
	
} */
}
