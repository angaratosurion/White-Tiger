package net.pariskoutsioukis.TigerDroid.REST;
//import android.app.Activity;

import net.pariskoutsioukis.TigerDroid.REST.Tasks.ExecutePostTask;
import net.pariskoutsioukis.TigerDroid.REST.Tasks.RestTaskModel;
import net.pariskoutsioukis.TigerDroid.Sqllite.SqlLiteManager;
import net.pariskoutsioukis.TigerDroid.Tools;
import net.pariskoutsioukis.TigerDroid.json.CommandModel;
import net.pariskoutsioukis.TigerDroid.json.JSon;
import net.pariskoutsioukis.TigerDroid.xml.DOMManager;
import net.pariskoutsioukis.TigerDroid.xml.XmlSax;
import net.pariskoutsioukis.TigerDroid.xml.xml;

import com.google.common.io.Files;





import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.DefaultedHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.xmlpull.v1.XmlPullParser;
import org.apache.http.client.utils.*;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;




























//import com.esotericsoftware.minlog.Log;
import com.google.gson.*;
import com.koushikdutta.async.future.Future;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpGet;
import com.koushikdutta.async.http.AsyncHttpPost;
import com.koushikdutta.async.http.AsyncHttpRequest;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.body.AsyncHttpRequestBody;
import com.koushikdutta.async.http.body.JSONObjectBody;
import com.koushikdutta.async.http.body.StringBody;
import com.koushikdutta.async.util.FileUtility;
import com.koushikdutta.ion.Ion;

import android.content.Context;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.util.Log;
//import org.apache.http.client.params;
public class TigerDroidClient {

com.koushikdutta.async.http.AsyncHttpClient client;
    String uri;
    Tools tools = new Tools();
    HttpParams httpParameters = new BasicHttpParams();
    int timeoutConnection = 30000;
    int timeoutSocket = timeoutConnection*2;
    
    int t=0;
    //HttpConnectionParams.setConnectionTimeouthttpParameters,timeoutConnection;
   
   // HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket;
  // DefaultHttpClient client ;//= new DefaultHttpClient(httpParameters);
    
  	JSon  jsmngr= new JSon();
 // DOMManager xmlmngr = new DOMManager();
  	//xml xmlmngr = new xml();
  	XmlSax xmlmngr = new XmlSax();
    public final long MAXREQSize=2147483647;
    
    public String[] Cells;
   // public static   final int dport=49152;
   Context ctx;
  
    public TigerDroidClient()
    {
       // client = new Client();

     // this.start();
    	//HttpConnectionParams.setConnectionTimeout(httpParameters, timeoutConnection*4);
    	//HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket*4);
    	//client = new DefaultHttpClient(httpParameters);
    	
    	
    	
    	
    //	DefaultedHttpContext  ctx ;
    	
    	




    }
    public TigerDroidClient(Context cont)
    {
       // client = new Client();

     // this.start();
    	//HttpConnectionParams.setConnectionTimeout(httpParameters, timeoutConnection*2);
    	//HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket*2);
    	//client = new DefaultHttpClient(httpParameters);
    	
    	//this.ctx=(HttpContext) cont;
    	this();
    	
    	 




    }




    public String GetURI() {
        try {

            return uri;

        } catch (Exception ex) {

            Tools.Errorhandling(ex);
            return null;


        }


    }

    public void SetURI(String serverip) {


        try {
            if (serverip!= null) {

                uri ="http://"+ serverip+"/White_Tiger/Json/";

            }

        } catch (Exception ex) {
            //return null;
            Tools.Errorhandling(ex);

        }

    }

    public String GetServerVersion() {

        try {
            String ap = null;


            ap = ExecutePostCommand("GetVersion", null);


            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }
    }

   /* public Boolean Login(String username, String pass) {
        try {
            Boolean ap = false;

            if ((username != null) && (pass != null)) {
                String[] params = new String[13];
                params[0] = username;
                params[1] = pass;
                ap = Boolean.parseBoolean(ExecuteGetCommand("Login", params));


            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return false;


        }
    }  */

  String  ExecuteGetFileCommand(String url,String [] params) {


        try {
          String ap = null;
           String jscmd,filename=null,command="GetFile";
         //   this.client= AsyncHttpClient.getDefaultInstance();
           // jscmd= jsmngr.CreateJson(command,params).toString();
            StringBuilder builder = new StringBuilder();
            HttpConnectionParams.setConnectionTimeout(httpParameters, timeoutConnection*80);
        	HttpConnectionParams.setSoTimeout(httpParameters, timeoutSocket*80);
        	//client = new DefaultHttpClient(httpParameters);
          //  if (tools.ArrayParamToString(params) == null)
    		{
    			//return null;

            }
    		int idx = url.lastIndexOf("/");
    		if ( idx >=0)
    		{
    		filename= url.substring(idx + 1) ;
    		}
    	
    		 
               
               
            
         
             
            
	          
	     HttpGet getrequest = new HttpGet(url);
       
	 AsyncHttpGet req= new AsyncHttpGet(getrequest.getURI().toString());
	    
       Future<File> tmp3= client.executeFile(req,"/sdcard/"+filename, new AsyncHttpClient.FileCallback()
        {
	
        	@Override
        	public void onCompleted(Exception e, AsyncHttpResponse arg1, File arg2)
        	{
	
        		if (e != null)
        		{
        			e.printStackTrace();
        			return;
        		}
        	  Log.i(Tools.TAG,arg2.getName());
        	  t++;
        	 // this.notify();
        	  
		
        	}
        }) ;
     
     //  Thread.currentThread().wait(this.timeoutSocket*80);
       ap=tmp3.get().getAbsolutePath();
  
      
        
   
	
 
		

            return ap;
        } 
        catch (Exception ex)
        {
            Tools.Errorhandling(ex);
            return null;


        }


    }
  
   String  ExecutePostCommand(String command, String[] params) {


        try {
            String  ap = null;
			String tmp;
            String jscmd;
            String filename=null;
            CommandModel cmd=null;
            if (command != null) {
            
            	// tmp="";
              jscmd= jsmngr.CreateJson(command,params).toString();
          
          this.client= AsyncHttpClient.getDefaultInstance();
          
             
            HttpPost request = new HttpPost(uri+command);
                request.setHeader("Accept", "application/json");
                request.setHeader("Content-type", "application/json");
                //request.
                StringEntity se = new StringEntity(jscmd);
                se.setContentType("application/json");
              //  client.setParams(params);
                AsyncHttpPost req= new AsyncHttpPost(request.getURI().toString());
                
                
              
          
              
             
                request.setEntity(se);
               // StringBody body =  AsynchttpRequest..
                req.setBody(new JSONObjectBody(jsmngr.CreateJSon(command, params)));
               req.asHttpRequest().setHeaders(request.getAllHeaders());
             //  AsyncHttpRequest req2 = AsyncHttpRequest.create(request);
             
               
               
               // body.
              // req.se
             //  client.setTimeout(timeoutSocket*3);
               // AsyncHttpClient.StringCallback
             
              Future<String> tmp2= client.executeString(req,new AsyncHttpClient.StringCallback() {
				
				@Override
				public void onCompleted(Exception e, AsyncHttpResponse arg1, String arg2)
				{
					if (e != null) {
						 e.printStackTrace();
						 return;
						 }
				//	cmd= jsmngr.GetValues(arg2);
					Log.i(Tools.TAG,arg2);
					
					
					
				}
			}); 
             cmd = this.jsmngr.GetValues(tmp2.get());
           
         	
            
                if ((cmd.exception==null) ||(cmd.exception!="none"))
                {
                  return cmd.data;
                }
            
           
            	
        	
            	
            		
            
            
            
            
            
       	          
            		
            		  
            	}
                






            


            return ap;
        } 
        catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }


    }


    public String[] ListDatabses(String username, String pass) {
        try {
            String[] ap = null;

            if ((username != null) && (pass != null)) {
                String[] params = new String[13];
                params[0] = username;
                params[1] = pass;
                String t= ExecutePostCommand("ListDatabases", params);
               // ap = this.xmlmngr.GetArray(this.jsmngr.GetValues("ListDatabasesResult"+res));
                ap=t.split(",");


            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }


    }

    public String[] ListTables(String username, String pass, String dbname) {
        try {
            String[] ap = null;

            if ((username != null) && (pass != null) && (dbname != null)) {
                String[] params = new String[13];
                params[2] = username;
                params[3] = pass;
               ap= ExecutePostCommand("ListTables",params).split(",");
              //  ap = null;

            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }


    }

/*
    public XmlPullParser LoadTable(String recordtag, String username, String pass, String dbname, String tablename) {
        try {
            XmlPullParser ap = null;

            if ((username != null) && (pass != null) && (dbname != null)
                    && (tablename != null) && (recordtag != null)) {
                String[] params = new String[13];
                params[0] = recordtag;
                params[1] = username;
                params[2] = pass;
                params[3] = dbname;
                params[4] = tablename;
               // ap = xmlmngr.(this.jsmngr.GetValues("LoadTable",ExecutePostCommand("LoadTable", params)));


            }

            return ap;
        } catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }
    }

 */
   private boolean isCellTag(String localName)
    {
        try {
            boolean ap = false;
            if (localName != null) {

                for (int i = 0; i < Cells.length; i++)
                {
                    if (Cells[i] == localName)
                    {
                        return true;
                    }


                }


            }

            return ap;
        }

    catch( Exception ex)
    {
        Tools.Errorhandling(ex);
        return false;

    }

}
   public String GetElemntName(String username,String dbname)
   {
       try {
           String ap = "";
           if ((username != null)&&(dbname!=null)) {


              ap=username+"_"+dbname;

           }

           return ap;
       }

       catch( Exception ex)
       {
           Tools.Errorhandling(ex);
           return null;

       }
   }
public XmlPullParser LoadTableToSQLLite(String recordtag,String username,String pass,String dbname,String tablename
		,SqlLiteManager sqlmngr)
{
	try
	{
		XmlPullParser ap=null;

		
		if((username!=null) &&(pass!=null) &&(dbname!=null)
			&&(tablename!=null) &&(recordtag!=null) &&(sqlmngr!=null))
		{
			 String[] params = new String[13];
             
             params[0]="pynakas";
     		params[1]=recordtag;
     		params[2]=username;
     		params[3]=pass;
     		params[4]=dbname;
     		params[5]=tablename;
     		params[6]="";
     		params[7]="";
     		params[8]="";
			

			//ap= this.LoadTable(recordtag, username, pass, dbname, tablename);
       //  String [] cells=this.GetColumns(username, pass, dbname,tablename);
//

           // sqlmngr.CreateorOpenDB(dbname,tablename,cells);
     		String urlpath=ExecutePostCommand("LoadTable", params);
     		params[6]=urlpath;
     		File xml=new File(this.ExecuteGetFileCommand(urlpath,params));
     	 
     		String elemnt =this.GetElemntName(username, tablename);
            xmlmngr.AttachXmltoSQLLite(sqlmngr, xml, tablename,Cells);
			
          //  int eventType= ap.getEventType();
           /* while (eventType!=XmlPullParser.END_DOCUMENT)
            {    ArrayList <String> text = new ArrayList<String>();

                 if(eventType==XmlPullParser.START_TAG)
                 {
                     if ( isCellTag(ap.getName()))
                     {
                         text.add(ap.getText());

                     }
                 }
                else if (eventType == XmlPullParser.END_TAG)
                 {

                 }
                else if (eventType== XmlPullParser.TEXT)
                 {



                 }
                sqlmngr.addNewRecord((String [])text.toArray());
                



            }*/




			
			
		}
		
		return ap;
	}
	catch(Exception ex)
	{
		Tools.Errorhandling(ex);
		return null;
		
		
	}
}

public SqlLiteManager DecryptTable(String root, String recordtag, String username, String dbname, String table, String pass, String alg, String hashalg,String passphrase,
SqlLiteManager sqlmngr)
{
	try
	{
		SqlLiteManager ap=null;
		
		String [] params = new String[13];
		if((root!=null)&&(recordtag!=null)&&(username!=null)&&
				(dbname!=null)&&(table!=null)&&
				(pass!=null)&&(alg!=null) &&
				(hashalg!=null)&&(passphrase!=null))
			
		{		
		params[0]=root;
		params[1]=recordtag;
		params[2]=username;
		params[3]=dbname;
		params[4]=table;
		params[5]=pass;
		params[6]=alg;
		params[7]=hashalg;
		params[8]=passphrase;
		
			//ap= xmlmngr.ReadXml(this.jsmngr.GetValues("DecryptTable",ExecutePostCommand("DecryptTable",params )));
			
			
		
		}
		return ap;
	}
	catch(Exception ex)
	{
		Tools.Errorhandling(ex);
		return null;
		
		
	}
}
/*public XmlPullParser Find(String username, String pass,String dbname, String table, String cell, String value)
{
	try
	{
		XmlPullParser ap=null;
		
		String [] params = new String[6];
		if((username!=null)&&(pass!=null)&&(dbname!=null)
				&&(table!=null)&&(cell!=null)&&(value!=null))
			
		{		
		
		params[0]=username;
		params[1]=pass;
		params[2]=dbname;
		params[3]=table;
		params[4]=cell;
		params[5]=value;
		
		
			ap= xmlmngr.ReadXml(ExecuteGetCommand("Find",params ));
			
			
		
		}
		return ap;
	}
	catch(Exception ex)
	{
		Tools.Errorhandling(ex);
		return null;
		
		
	}
}   */
public Boolean IsTableEncrypted(String username, String pass, String dbname, String tablename)
{try
{
	Boolean ap=false;
	
	if((username!=null) &&(pass!=null))
	{
		String [] params= new  String [13];
		params[2]=username;
		params[3]=pass;
		params[4]=dbname;
		params[5]=tablename;
		ap= Boolean.parseBoolean(ExecutePostCommand("IsTableEncrypted",params ));
		
		
	}
	
	return ap;
}
catch(Exception ex)
{
	Tools.Errorhandling(ex);
	return false;
	
	
}
	
	
}
public String [] GetColumns(String username, String pass, String dbname, String tablename)
{
	try
	{ String [] ap=null; int i;
	List<String> a = new ArrayList<String>();
		if((username!=null) &&(pass!=null) &&(dbname !=null)&&(tablename!=null))
		{
			String [] params= new  String [13];
			params[2]=username;
			params[3]=pass;
			params[4]=dbname;
			params[5]=tablename;
			String tmp=  this.ExecutePostCommand("GetColumns", params);
            ap=tmp.split(",");
            for(i=0;i<ap.length;i++)
            {
            	if(ap[i]!="none")
            	{
            	a.add(ap[i]);
            	}
            }
            ap=(String[]) a.toArray();
			
		}
		return ap;
		
	}
	catch(Exception ex)
	{
		Tools.Errorhandling(ex);
		return null;
		
		
	}
	
}
  

}
