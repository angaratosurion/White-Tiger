

package net.pariskoutsioukis.TigerDroid;
import java.io.*;
import java.util.Date;

//import android.annotation.SuppressLint;
import android.os.*;
import android.util.Log;

public class Tools {
	

private static String bugfile = "errors.txt";
	public String ArrayParamToString(String[] params)
	{
		try
		{ int i;
			String ap=null;
			
			if((params!=null) &&(params.length >0))
			{
				
				for(i=0;i<params.length;i++)
				{
					ap+="&"+params[i];
				}
				
			}
			
			
			return ap;
		}
		catch(Exception ex)
		{
			Tools.Errorhandling(ex);
			return null;
			
			
		}
		
		
	}
//@SuppressLint("ParserError")
public static final String TAG="TigerDroid";
    public static void Errorhandling(Exception ex)
    {
        Log.d(TAG, ex.toString(), ex);
        File f = new File(Environment.getExternalStorageDirectory()+"/TigerDroid/Logs");
        File ef =new  File(Environment.getExternalStorageDirectory()+"/TigerDroid/Logs/"+TAG+bugfile);
        Date date =new Date();
       // throw (ex);

        if ( !f.exists())
        {
            f.mkdir();
        }
        if ( ef.exists())
        {
            try {
                BufferedReader br = new BufferedReader(new FileReader(ef));
                String line,in="",out="";

                while ((line = br.readLine()) != null) {
                    in+=line+'\n';
                    // text.append('\n');
                }
                br.close();
                BufferedWriter bw = new BufferedWriter(new FileWriter(ef));
                out=in+"\n"+date.toString()+"\n"+ex.toString()+" : "+ex.fillInStackTrace().toString() ;
                bw.write(out);
                bw.close();


            }
            catch (IOException n)
            {
                // ef.createNewFile();
            }



        }
        else {
            try {
                ef.createNewFile();
                String out="";


                BufferedWriter bw = new BufferedWriter(new FileWriter(ef));
                out=date.toString()+"\n"+ex.toString()+" : "+ex.fillInStackTrace().toString() ;
                bw.write(out);
                bw.close();


            }
            catch (IOException n)
            {
                // ef.createNewFile();
            }

        }


    }
}
