package net.pariskoutsioukis.TigerDroid.xml;

import android.util.Log;
import net.pariskoutsioukis.TigerDroid.Sqllite.SqlLiteManager;
import net.pariskoutsioukis.TigerDroid.Tools;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

/**
 * Created by angarato surion on 20/7/2014.
 */
public class DOMManager {
	//DocumentParser parser = new DocumentParser();
    public Document getDomElement(File xml) {
        Document doc = null;
       DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        try {

           DocumentBuilder db = dbf.newDocumentBuilder();

           /* InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(xml));
            doc = db.parse(is);*/
         doc=db.parse(xml);
        	
        	return doc;
          

        } 
        catch (SAXException e) {
            Log.e("Error: ", e.getMessage()+ " "+ e.fillInStackTrace());
            Tools.Errorhandling(e);
            return null;
        } catch (IOException e) {
            Log.e("Error: ", e.getMessage()+ " "+ e.fillInStackTrace());
            Tools.Errorhandling(e);
            return null;
        }
 catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

    }


    public String getValue(Element item, String str) {
        NodeList n = item.getElementsByTagName(str);
        return this.getElementValue(n.item(0));
    }

    public final String getElementValue(Node elem) {
        Node child;
        if (elem != null) {
            if (elem.hasChildNodes()) {
                for (child = elem.getFirstChild(); child != null; child = child.getNextSibling()) {
                    if (child.getNodeType() == Node.TEXT_NODE) {
                        return child.getNodeValue();
                    }
                }
            }
        }
        return "";
    }
    public SqlLiteManager  AttachXmltoSQLLite(SqlLiteManager sqlmngr,File xml, String ele)
    {
        try
        {   SqlLiteManager ap =null;

            if((sqlmngr!=null)&&(xml!=null) &&(ele !=null)) {
                Document doc = this.getDomElement(xml);
                doc.normalizeDocument();
                NodeList nl = doc.getElementsByTagName(ele);
                for (int i = 0; i < nl.getLength(); i++) {

                    ArrayList<String> text = new ArrayList<String>();
                    NodeList cld = nl.item(i).getChildNodes();
                    for (int j = 0; j < cld.getLength(); j++)
                    {
                        Node nd = cld.item(i);
                        Log.i(Tools.TAG, nd.getNodeName());
                        text.add(nd.getNodeValue());

                    }
                    sqlmngr.addNewRecord(text.toArray());

                }

            }
         return sqlmngr;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return null;
        }
    }

}
