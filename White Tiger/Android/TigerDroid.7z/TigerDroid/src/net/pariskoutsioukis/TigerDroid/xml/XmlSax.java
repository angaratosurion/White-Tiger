package net.pariskoutsioukis.TigerDroid.xml;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import net.pariskoutsioukis.TigerDroid.Tools;
import net.pariskoutsioukis.TigerDroid.Sqllite.SqlLiteManager;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import android.util.Log;



public class XmlSax 
{
	public SqlLiteManager  AttachXmltoSQLLite(SqlLiteManager sqlmngr,File xml, String ele,
			String [] cells)
	{
	    try
	    { 
	    	SqlLiteManager ap =null;
	    	 SAXParserFactory parserFactor = SAXParserFactory.newInstance();
	    	    SAXParser parser = parserFactor.newSAXParser();
	    	  XmlSaxHandler handler = new XmlSaxHandler();
	    	  //  parser.parse(ClassLoader.getSystemResourceAsStream("xml/employee.xml"),      handler);
	        
	       
	    	 // Log.i(Tools.TAG,rec[0]);

	        if((sqlmngr!=null)&&(xml!=null) &&(ele !=null)&&(cells!=null)) 
	        {
	        
	        	handler.setCells(cells);	        
	        	handler.setElemnt(ele);
	        	parser.parse(xml, handler);
	        	for ( String[] rec: handler.GetRecords())
	        	{
	        	      sqlmngr.addNewRecord(rec);
	        	     
	        	      
	        	    
	        	}
	        xml.delete();
	        
	           

	        }
	     return sqlmngr;
	    }
	    catch (Exception e)
	    {
	        Tools.Errorhandling(e);
	        return null;
	    }
	}



}
