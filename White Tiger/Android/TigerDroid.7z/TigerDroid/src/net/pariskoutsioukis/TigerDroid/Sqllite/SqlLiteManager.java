package net.pariskoutsioukis.TigerDroid.Sqllite;

/**
 * Created by angarato surion on 10/1/2014.
 */

import android.content.ContentValues;
import android.nfc.Tag;
import android.util.Log;
import net.pariskoutsioukis.TigerDroid.*;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;






import android.content.Context;

import com.android.internal.util.XmlUtils;

import org.xml.sax.helpers.*;

import android.database.*;
import android.database.sqlite.*;

import java.util.ArrayList;
import java.util.List;

public class SqlLiteManager extends SQLiteOpenHelper  {
   //SQLiteDatabase db = new SQLiteDatabase();
   SQLiteDatabase DB;
    String DATABASE_NAME,Table_Name;
   final String KEY_ID="_id";
    String [] pkeys;
    String [] Cells;
    SQLiteDatabase.CursorFactory factor;
    String CREATE_TABLE="";
    public String [] GetCells()
    {
    	return Cells;
    }
    public void setCells(String [] cells)
    {
    	Cells=cells;
    }
    public String [] getPrimaryKeys()
    {
    	return pkeys;
    }
    public void setPrimaryKeys(String [] keys)
    {
    	pkeys=keys;
    }
    public SqlLiteManager (Context context, String name,SQLiteDatabase.CursorFactory factory, int version)
    {  super(context, name, factory, version);
        this.DATABASE_NAME=name;
        this.factor=factory;
    }
   
	public SqlLiteManager(Context cont ,String dbname,String table)
    {
        super(cont,dbname,null,1);
        DATABASE_NAME=dbname;
        Table_Name=table;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try
        {
           // SQLiteDatabase db= this.getWritableDatabase();
            db.execSQL(CREATE_TABLE);
            this.DB=db;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i2) {
        try
        {
            db.execSQL("DROP TABLE IF EXISTS " +Table_Name);
            onCreate(db);
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
        }

    }

    public void CreateorOpenDB(String dbfilename,String tablename,String [] tcells)
    {
        try
        {
            int eventType ;
            if ( (dbfilename !=null) &&(tablename!=null))
            {    DATABASE_NAME=dbfilename;
                 Table_Name=tablename;
                ArrayList<String> tprimkey= new ArrayList<String>();

                Cells=tcells;
              this.getWritableDatabase().execSQL("DROP TABLE IF EXISTS " +Table_Name);

                CREATE_TABLE = "CREATE TABLE "+ tablename +"(\n";
                for (int i=0;i<tcells.length;i++)
                {
                    if ( tcells[i].startsWith("_."))
                    {
                        CREATE_TABLE+=tcells[i].replace("_.","_") + " TEXT UNIQUE, ";
                        tprimkey.add(tcells[i]);
                    }
                    else
                    {
                        if(i<tcells.length-1) {
                            CREATE_TABLE += tcells[i] + " TEXT, ";
                        }
                        else
                        {
                            CREATE_TABLE += tcells[i] + " TEXT";

                        }
                    }

                }

                CREATE_TABLE+=", "+KEY_ID+"  INTEGER PRIMARY KEY AUTOINCREMENT);";

                  this.DB = this.getWritableDatabase()  ;
                this.DB.execSQL(CREATE_TABLE);
                pkeys= (String [])tprimkey.toArray();

            }






        }
        catch(Exception ex)
        {
            Tools.Errorhandling(ex);
        }


    }
    public void CreateorOpenDB(String dbfilename,String tablename,String [] tcells,Boolean dropexisting)
    {
        try
        {
            int eventType ;
            if ( (dbfilename !=null) &&(tablename!=null))
            {    DATABASE_NAME=dbfilename;
                 Table_Name=tablename;
                ArrayList<String> tprimkey= new ArrayList<String>();

                Cells=tcells;
                if ( dropexisting)
                {
                  this.getWritableDatabase().execSQL("DROP TABLE IF EXISTS " +Table_Name);
                }

                CREATE_TABLE = "CREATE TABLE "+ tablename +"(\n";
                for (int i=0;i<tcells.length;i++)
                {
                    if ( tcells[i].startsWith("_."))
                    {
                        CREATE_TABLE+=tcells[i].replace("_.","_") + " TEXT UNIQUE, ";
                        tprimkey.add(tcells[i]);
                    }
                    else
                    {
                        if(i<tcells.length-1) {
                            CREATE_TABLE += tcells[i] + " TEXT, ";
                        }
                        else
                        {
                            CREATE_TABLE += tcells[i] + " TEXT";

                        }
                    }

                }

                CREATE_TABLE+=", "+KEY_ID+"  INTEGER PRIMARY KEY AUTOINCREMENT);";

                  this.DB = this.getWritableDatabase()  ;
                this.DB.execSQL(CREATE_TABLE);
                pkeys= (String [])tprimkey.toArray();

            }






        }
        catch(Exception ex)
        {
            Tools.Errorhandling(ex);
        }


    }
   
    private int [] indexPrimaryKeyPositions()
    {

    	try
    	{
    		
    		int [] ap=null;
    		int i=0,j=0;
    		if ((pkeys!=null) &&(this.Cells!=null))
    		{
    			ap= new int [pkeys.length];
    			for(i=0;i<Cells.length;i++)
    			{
    				for(j=0;j<pkeys.length;j++)    				
    				{
    					Log.i(Tools.TAG,"Pkeys" + pkeys[j]);
    					if ( Cells[i]==pkeys[j])
    					{
    					
    						ap[j]=i;
    					}
    				}
    			}
    		}
    		
    		
    		
    		return ap;
    		
    	}
    	 catch (Exception e)
        {
            Tools.Errorhandling(e);
            return null;
        }
    	
    }
    public Boolean CheckifRecordExist(Object [] vals)
    {
    	try
    	{
    		Boolean ap= false;
    		int i=0;
    		int [] pos;
    		
    		if ( (vals!=null&&(this.pkeys!=null)))
    		{
    			pos= this.indexPrimaryKeyPositions();
    			if(pos !=null)
    			{
    			String Qry = "SELECT * FROM " + Table_Name +" WHERE ";
    			if (pkeys.length>1)
    			{
    			
    			
    				for(i=0;i<pkeys.length;i++)
    			
    				{
    				Qry+=pkeys[i]+" = "+vals[pos[i]]+" AND ";
    			
    			
    				}
    			}
    			else
    			{
    				Qry+=pkeys[0]+" = \""+vals[pos[0]]+"\"";
    			}
    				SQLiteDatabase db = this.getReadableDatabase();
    				Cursor cursor = db.rawQuery(Qry, null);
    				
    				
    				if(cursor.getCount()>0)
    				{
    					ap=true;
    				}
    				cursor.close();
                
    			}
    		}
    		
    		
    		
    		return ap;
    	}
    	  catch (Exception e)
        {
            Tools.Errorhandling(e);
            return false;
        }
    }
    public void addNewRecord(Object [] vals)
    {
        try {
            if(( Cells !=null)&&(vals!=null) &&(vals.length==Cells.length))
            {
              
                ContentValues values = new ContentValues();
                if (!this.CheckifRecordExist(vals))
                {
                	  SQLiteDatabase db = this.getWritableDatabase();
                //	return ;
                
            
                	for ( int i =0 ; i< Cells.length;i++)
                	{
             //      Log.i(Tools.TAG,String.valueOf(i));
               
                		Log.i(Tools.TAG,Cells[i]);
            	  
                        values.put(Cells[i],String.valueOf(vals[i]));
               
                	}
                if (values.size()>0) 
                {
                    db.insert(Table_Name, null, values);
                    db.close();
                  }
                db.close();
                }
            }
            
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
        }

    }
   

    public Cursor getAllRecords()
    {
        try {
           // List<Waypoint> lstpoi = new ArrayList<Waypoint>();
            String selectqry = "SELECT * FROM " + Table_Name  ;
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(selectqry, null);
            if( cursor !=null)
            {
                cursor.moveToFirst();
            }

            return cursor;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return null;
        }

    }
    public int getRecordCount()
    {
        try {
            String countQry = "SELECT * FROM " + Table_Name;
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(countQry, null);
            cursor.close();
            return cursor.getCount();
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return -1;
        }


    }
    public int updateRecord(String [] vals)
    {
        try {
            if ( Cells!=null) {
                SQLiteDatabase db = this.getWritableDatabase();
                ContentValues values = new ContentValues();
                int p=0;
                for(int i=0;i<Cells.length;i++)
                {
                    values.put(Cells[i],vals[i]);
                }
                if ( pkeys !=null) {
                    for( int i=0 ;i<Cells.length;i++)
                    {
                          if( Cells[i]==pkeys[0])
                          {
                              p=i;
                              break;
                          }
                    }
                    return db.update(Table_Name, values, pkeys[0] + " =?", new String[]{vals[p]});
                }
                return db.update(Table_Name, values, null,null);
            }
            return 0;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return -1;
        }


    }

    public  void deleteRecord(int id)
    {
        try {
            SQLiteDatabase db = this.getWritableDatabase();
            //db.delete(Table_Name, KEY_ID + " =?", new String[]{String.valueOf(id)});
            db.close();
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
        }
    }
    public  void deleteRecord(String col, String val)
    {
        try {
        	
        	  if (col != null && val != null)
        	  {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete(Table_Name, col + " =?", new String[]{val});
            
        	  
            db.close();
        	 
        	  }
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
        }
    }

    public Cursor findRecord(String col, String val)
    {
        try {
            if (col != null && val != null) {
                SQLiteDatabase db = this.getReadableDatabase();
                String selectqry= "SELECT * FROM "+ Table_Name +" WHERE "+col + " LIKE ?";
               /* Cursor cursor = db.query(TABLE_NAME, new String[]{KEY_ID, KEY_NAME, KEY_TYPE, KEY_DESCRIPTION, KEY_DATETIME, KEY_LAT,
                        KEY_LON, KEY_COMMENT}, col + " LIKE?", new String[]{val}, null, null, null);     */
               
              Cursor cursor = db.rawQuery(selectqry,new String []{val});
             

                if (cursor != null) {
                    cursor.moveToFirst();
                    return cursor;
                }
               // return poi;
            }
            return null;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return null;
        }


    }

    public Cursor getRecord(String col, String val)
    {
        try {
            if (col != null && val != null) {
                SQLiteDatabase db = this.getReadableDatabase();
                String selectqry= "SELECT * FROM "+ Table_Name +" WHERE "+col + " =?";
               /* Cursor cursor = db.query(TABLE_NAME, new String[]{KEY_ID, KEY_NAME, KEY_TYPE, KEY_DESCRIPTION, KEY_DATETIME, KEY_LAT,
                        KEY_LON, KEY_COMMENT}, col + " LIKE?", new String[]{val}, null, null, null);     */
                Cursor cursor = db.rawQuery(selectqry,new String []{val});

                if (cursor != null) {
                    cursor.moveToFirst();
                    return cursor;
                }
               // return poi;
            }
            return null;
        }
        catch (Exception e)
        {
            Tools.Errorhandling(e);
            return null;
        }


    }

}
