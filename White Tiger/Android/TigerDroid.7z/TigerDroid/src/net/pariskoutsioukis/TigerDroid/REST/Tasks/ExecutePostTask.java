package net.pariskoutsioukis.TigerDroid.REST.Tasks;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import net.pariskoutsioukis.TigerDroid.Tools;
import net.pariskoutsioukis.TigerDroid.json.CommandModel;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.DefaultHttpClient;

import android.os.AsyncTask;
import android.util.Log;

public class ExecutePostTask extends AsyncTask<RestTaskModel,Void,InputStream>
{


	@Override
	protected InputStream doInBackground(RestTaskModel... params) 
	{
		try 
		{
			InputStream ap=null;//,tmp="";
			String line=null;
			
			if ( params!=null)
			{
				RestTaskModel model=params[0];
				if( model!=null)
				{
					 HttpResponse response = model.client.execute(model.Request);
					 HttpEntity entity = response.getEntity();
		              // Thread.sleep(timeoutSocket);
					 ap= entity.getContent();
		              /*BufferedReader reader = new BufferedReader(new InputStreamReader(is)); 
		               
		                Log.i(Tools.TAG, String.valueOf(entity.getContentLength()));
		                while((line = reader.readLine()) != null){
		                    tmp+=line;
		                }
		                is.close();
		                reader.close();
		                ap=tmp;
					*/
					
				}
			}
			
			
			return ap;
		}
		catch (Exception ex) {
            Tools.Errorhandling(ex);
            return null;


        }
		//return null;
	}



	

}
