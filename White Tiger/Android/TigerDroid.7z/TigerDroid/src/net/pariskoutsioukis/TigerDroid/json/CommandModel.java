package net.pariskoutsioukis.TigerDroid.json;

/**
 * Created by angarato surion on 16/6/2014.
 */
public class CommandModel {
   /* public class CommandModel
    {
        /* args[0] root
                           args[1] record tag
                           * args[2] username
                           * args[3] password
                           * args[4] db name
                           * args[5] tablename
                          */
      public String commandname;
        public String root ;
        public String recordtag ;
        public String username ;
        public String password ;
        public String dbname ;
        public String tablename ;
        public String data;
        public String algorith ;
        public String hashalg   ;
        public String passphrase;
        public String friendlyerrormsg;
        public String exception ;
        public String dataformat;
}
